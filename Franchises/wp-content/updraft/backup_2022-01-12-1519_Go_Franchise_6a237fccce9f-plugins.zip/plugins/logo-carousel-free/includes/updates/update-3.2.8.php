<?php
/**
 * Update version.
 *
 * @package logo-carousel-free
 */

update_option( 'logo_carousel_free_version', '3.2.8' );
update_option( 'logo_carousel_free_db_version', '3.2.8' );
